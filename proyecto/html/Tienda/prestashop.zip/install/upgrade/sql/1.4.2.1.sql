SET NAMES 'utf8';

DELETE FROM `PREFIX_configuration_lang` WHERE 1 AND `value` is NULL AND `date_upd` is NULL;
