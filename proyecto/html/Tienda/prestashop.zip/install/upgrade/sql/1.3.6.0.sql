SET NAMES 'utf8';

/* PHP:update_products_ecotax_v133(); */;
